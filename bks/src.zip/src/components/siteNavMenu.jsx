/* ───────── SampleNavMenu.jsx – updated, stable version ───────── */
import React, { useEffect, useState } from "react";
import { siteNav } from "../data/siteNav.ts";

/* ---------- Recursive branch ---------- */
function MenuBranch({ node, depth = 0, delay = 0, reset }) {
  const [expanded, setExpanded] = useState(false);
  const hasKids = node.children?.length > 0;

  useEffect(() => setExpanded(false), [reset]);

  const handleClick = (e) => {
    if (window.innerWidth <= 768 && hasKids) {
      e.preventDefault();
      setExpanded((x) => !x);
    }
  };

  return (
    <div
      className={`nav-item${hasKids ? " has-dropdown" : ""}${
        expanded ? " expanded" : ""
      }`}
      style={{ animationDelay: `${0.1 + delay}s` }}
    >
   <div className="menu-row">
  <a
    href={node.href || "#"}
    className={depth ? "menu-link has-expand" : "nav-link has-expand"}
    onClick={handleClick}
  >
    {/* Left expand icon */}
    {hasKids && (
      <span className="left-icon mobile-only">{expanded ? "▲" : "▼"}</span>
    )}
    {node.label}

    {/* Right-side go arrow */}
    {node.href && (
    <span
  className="right-arrow mobile-only"
  onClick={(e) => {
    e.stopPropagation();
    window.location.href = node.href;
  }}
>
  ●
</span>
    )}
  </a>
</div>



      {hasKids && (
        <div
          className={depth === 0 ? "dropdown-panel" : "submenu"}
          data-depth={depth}
          style={{ zIndex: 1000 + depth * 5 }}
        >
          {node.children.map((kid) => (
            <MenuBranch
              key={kid.label}
              node={kid}
              depth={depth + 1}
              delay={delay}
              reset={reset}
            />
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------- Root nav component ---------- */
export default function SampleNavMenu() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [resetSignal, setResetSignal] = useState(0);

  const closeMobileMenu = () => {
    setMobileOpen(false);
    document.body.classList.remove("mobile-open");
    document.body.style.overflow = "";
  };

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    document.body.classList.toggle("mobile-open", mobileOpen);
    if (!mobileOpen) setResetSignal((n) => n + 1);
  }, [mobileOpen]);

  useEffect(() => {
    const nav = document.querySelector(".nav-bar");
    if (!nav) return;
    const parents = nav.querySelectorAll(".has-dropdown");

    const onEnter = (e) => {
      const panel = e.currentTarget.querySelector(
        ":scope > .submenu, :scope > .dropdown-panel"
      );
      if (!panel) return;

      panel.classList.remove("open-left", "open-right");
      const { style } = panel;
      const v = style.visibility;
      const d = style.display;
      style.visibility = "hidden";
      style.display = "block";

      requestAnimationFrame(() => {
        const rect = panel.getBoundingClientRect();
        style.visibility = v;
        style.display = d;
        const overR = rect.right > window.innerWidth;
        const overL = rect.left < 0;
        if (overR && !overL) panel.classList.add("open-left");
        else if (overL && !overR) panel.classList.add("open-right");
        else panel.classList.add("open-right");
      });
    };

    parents.forEach((p) => p.addEventListener("mouseenter", onEnter));
    return () =>
      parents.forEach((p) => p.removeEventListener("mouseenter", onEnter));
  }, []);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth > 768) closeMobileMenu();
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <header className="nav-wrapper">
      {!mobileOpen && (
        <button
          className="hamburger-circle"
          aria-label="Open menu"
          onClick={() => setMobileOpen(true)}
        >
          <span className="bar" />
          <span className="bar" />
          <span className="bar" />
        </button>
      )}

      <a
        href="mailto:wayne@k4studios.com"
        className="wh-logo"
        aria-label="Email Wayne Heim"
      >
        <img src="/images/WH.png" alt="WH logo" />
      </a>

      {mobileOpen && (
        <div className="nav-backdrop" onClick={closeMobileMenu} />
      )}

      <nav className={`nav-bar ${mobileOpen ? "open" : ""}`}>
        <div className="drawer-header">
          <button className="drawer-close" aria-label="Close menu" onClick={closeMobileMenu}>
            <span className="drawer-x">×</span>
          </button>
        </div>

        {siteNav.map((root, i) => (
          <MenuBranch
            key={root.label}
            node={root}
            delay={i * 0.1}
            reset={resetSignal}
          />
        ))}
      </nav>

      {/* ---------- Styles ---------- */}
      <style jsx>{`
.drawer-close {
  width: 32px;
  height: 32px;
  border: 1px solid #bbb;
  border-radius: 50%;
  background: #fff;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 0;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}

.drawer-x {
  font-size: 1.95rem;
  font-weight:600;
  line-height: 1;
  transform: translateY(-1px); /* 👈 this is the key nudge */
}

        /* util */
        @keyframes slideIn {
          from { transform: translateY(100%); opacity: 0; }
          to   { transform: translateY(0);   opacity: 1; }
        }

        .nav-wrapper {
          font-family: 'Glegoo', serif;
          position: relative;
          width: 100%;           /* gives abs-pos children full span */
        }

        /* ---------- Hamburger circle ---------- */
        .hamburger-circle {
          position: absolute;
          top: -1.1rem;
          left: 1rem;
          width: 35px;
          height: 35px;
          border: 2px solid #222;
          border-radius: 50%;
          background: none;
          display: none;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          padding: 0;
          cursor: pointer;
          z-index: 3000;
          opacity: 0.25;
        }
        .hamburger-circle .bar {
          width: 12px;
          height: 2px;
          background: #222;
          margin: 2px 0;
        }

        /* ---------- WH logo ---------- */
       /* WH logo for mobile — correct z-index and position */
.wh-logo {
  display: none;
  position: fixed;              /* ← use fixed instead of absolute */
  right: 3rem;
  top: 4.2rem;
  z-index: 3001;                /* higher than .nav-wrapper */
  pointer-events: auto;
}

.wh-logo img {
  width: 64px;
  opacity: 0.2;
  filter: grayscale(100%);
  transition: opacity 0.25s ease;
}

.wh-logo:hover img {
  opacity: 0.8;
}

/* Mobile only */
@media (max-width: 768px) {
  .wh-logo {
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }
}
        /* ---------- Desktop hides mobile controls ---------- */
        @media (min-width: 1023px) {
          .hamburger-circle,
          .wh-logo,
          .drawer-header,
          .drawer-close { display: none !important; }

          .nav-bar { display: flex; gap: 0; z-index: 1001; }
        }

        /* ---------- Mobile overrides ---------- */
        @media (max-width: 1024px) {

.nav-link,
.menu-link {
  display: block;
  width: 100%;
  padding: 0.65rem 1rem;
  border: 1px solid #bbb;
  background: #fff;
  color: #333;
  font-size: 1rem;
  margin-bottom: 0.35rem;
  box-shadow: 0 1px 2px rgba(0,0,0,0.06);
  border-radius: 4px;
}


.menu-link {
  border-bottom: 1px solid #ccc;
}

.nav-link:hover,
.menu-link:hover {
  background: #f4f3f0;
}


          .hamburger-circle,
          .wh-logo { display: inline-flex; }

          /* backdrop */
          .nav-backdrop {
            position: fixed; inset: 0;
            background: rgba(0,0,0,0.4);
            z-index: 2999;
          }

          /* drawer */
          .nav-bar {
            position: fixed; top: 0; left: 0;
            height: 100vh; width: 75%; max-width: 320px;
            background: rgba(255,255,255,0.75);
            backdrop-filter: blur(6px);
            overflow-y: auto;
            padding: 1rem 0.75rem;
            transform: translateX(-100%);
            transition: transform 0.35s ease;
            z-index: 3000;
          }
          .nav-bar.open { transform: translateX(0); }

          .drawer-header { display: flex; justify-content: center; margin-bottom: 0.5rem; }
          .drawer-close  {
            font-size: 1.75rem; width: 32px; height: 32px;
            border: 1px solid #bbb; border-radius: 50%;
            background: #fff; cursor: pointer;
          }

          /* flatten sub-menus in drawer */
          .dropdown-panel,
          .submenu {
            position: static !important;
            display: none !important;
            border: none; box-shadow: none;
            padding-left: 1rem; margin-top: 0.25rem;
          }
          .nav-item.expanded > .dropdown-panel,
          .nav-item.expanded > .submenu { display: block !important; 
          background:rgb(238, 237, 233);            /* subtle parchment fill */
  padding: 0.5rem;
  margin-left: 0.75rem;           /* match button indent */
  margin-right: 0.75rem;
  border-radius: 6px;
  box-shadow: inset 0 0 0 3px rgba(0, 0, 0, 0.1);
          }
          
        }

        /* ---------- Shared menu styles (unchanged) ---------- */
        .nav-item   { position: relative; animation: slideIn 0.5s ease forwards; opacity: 0; transform: translateY(30px); }
        .nav-link   { display:inline-block; padding:0.35rem 0.9rem; font-size:0.9rem; background:#fff; border:1px solid #bbb; color:#333; white-space:nowrap; }
        .nav-link:hover { background:#f7f6f1; }

        .menu-link  { display:block; padding:0.45rem 1rem; font-size:0.9rem; background:#fff; color:#222; border-bottom:1px solid #eee; }
        .menu-link:hover { background:#f1efe9; }

        .dropdown-panel { position:absolute; top:100%; left:0; background:#fff; border:1px solid #ccc; min-width:220px; box-shadow:0 4px 12px rgba(0,0,0,0.15); display:none; }
        .has-dropdown:hover > .dropdown-panel { display:block; }

        .submenu { position:absolute; top:0; right:100%; margin-right:-1px; background:#fff; border:1px solid #ccc; min-width:200px; box-shadow:0 4px 12px rgba(0,0,0,0.15); display:none; z-index:1000; }
        .has-dropdown:hover > .submenu { display:block; }


/* ─── Red chaser underline (desktop + mobile) ─── */
.nav-link,
.menu-link {
  position: relative;      /* keeps the underline inside each link */
  overflow: hidden;        /* hides stray pixels on scale-up */
}

.nav-link::after,
.menu-link::after {
  content: "";
  position: absolute;
  bottom: 0;
  left: 0;
  width: 0%;
  height: 2px;
  background: linear-gradient(to right, #a0522d 60%, rgba(160,82,45,0));
  transition: width 0.4s ease;
}

.nav-link:hover::after,
.menu-link:hover::after {
  width: 100%;
}

/* ---------- Row & arrow styling ---------- */


/* Row layout for left/right icons */
.menu-row {
  width: 100%;
}

/* Make the entire anchor flex layout */
.has-expand {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

/* Left icon (chevron) */
.left-icon {
  margin-right: 0.5rem;
  font-size: 0.85rem;
  color: #999; /* softened from #555 */
  opacity: 0.7; /* additional fade */
}

/* Right arrow (go-to link icon) */
.right-arrow {
  font-size: 0.95rem;
  transform: scaleY(.85) scaleX(0.85);
  background: #f7f6f1;
  border: 1px solid #ccc;
  border-radius: 3px;
  padding: 0.015rem 0.30rem;
  margin-left: auto;
  color:rgb(138, 43, 36);
  line-height: 1;
  font-weight: 900;
  opacity: 0.55;
  transition: background 0.2s, color 0.2s, border-color 0.2s;
}

.right-arrow:hover {
  color: #703a1d;
      }

@media (min-width: 1023px) {
  .mobile-only {
    display: none !important;
  }
}

      `}</style>
    </header>
  );
}
