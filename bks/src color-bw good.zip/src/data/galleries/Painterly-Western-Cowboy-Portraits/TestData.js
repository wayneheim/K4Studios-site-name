export const galleryData = [
  {
    id: "test-id-1",
    title: "Test Cowboy",
    description: "A test image to check data loading.",
    alt: "Test Cowboy Portrait",
    src: "https://via.placeholder.com/450x600.png?text=Test+Image",
    buyLink: "#",
    keywords: ["Test", "Cowboy", "Portrait"]
  }
];