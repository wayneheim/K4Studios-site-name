import { useEffect, useRef } from "react";
import { westernSlides } from "../data/Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/carousel.ts";
import "../styles/ImageBar2.css";

export default function ImageBar2() {
  const trackRef = useRef(null);

  /* Duplicate slides once so the animation can scroll -50 % with no gap */
  useEffect(() => {
    if (trackRef.current && trackRef.current.children.length === westernSlides.length) {
      trackRef.current.innerHTML += trackRef.current.innerHTML;
    }
  }, []);

  return (
    <section
      className="carousel"
      aria-label="Fine-Art Western Cowboy Photography Carousel"
      role="region"
      itemScope
      itemType="https://schema.org/ImageGallery"
    >
      <meta itemProp="name"    content="Painterly Western Cowboy Gallery"/>
      <meta itemProp="creator" content="K4 Studios"/>

      <div className="carousel-track" ref={trackRef}>
        {westernSlides.map((s, i) => (
          <figure className="carousel-slide" key={i} itemScope itemType="https://schema.org/ImageObject">
            <a href={s.href} title={s.alt} aria-label={s.alt}>
              <img src={s.src} alt={s.alt} loading="lazy" itemProp="contentUrl" />
            </a>
            <figcaption itemProp="description">{s.description}</figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
}
