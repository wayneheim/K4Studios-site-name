// Placeholder for gallery data
export const galleryData = [];
