export const galleryData = [
  {
  "id": "i-k4studios",
  "title": "Welcome to the Color Cowboy Gallery",
  "description": "Explore the grit, grace, and story behind each image.",
  "alt": "Welcome to the Color Cowboy Gallery",
  "src": "/images/gallery-intro-placeholder.jpg",  // ← update this if needed
  "buyLink": "",
  "keywords": [],
  "story": "",
  "notes": "",
  "rating": 0,
  "galleries": [
    "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Color"
  ],
  "visibility": "ghost",
  "sortOrder": -1
},
{
    "id": "i-8zkKqtg",
    "title": "Shoe Shine Boy",
    "description": "painterly fine art photo of 1920's themed image of young boy giving a spit shine to a businessman's shoes.",
    "alt": "Shoe Shine Boy",
    "src": "https://photos.smugmug.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-8zkKqtg/0/KJSMCgVzR8P7psJj8ZbPjRfPZ3nHF7xh6hmHkCtbx/XL/12x18_O1H0006-Edit-2-Edit-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-8zkKqtg/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "painterly fine art photo of 1920's themed image of young boy giving a spit shine to a businessman's shoes.",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 0
  },
  {
    "id": "i-WSh3Nqv",
    "title": "Phoning It In",
    "description": "1920's style police call box being used by a townsperson to call in a crime.",
    "alt": "Phoning It In",
    "src": "https://photos.smugmug.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-WSh3Nqv/0/M7tMb77WPkGcnhFZLSXmvjdTFG4gL4ckbBPKrBfFn/XL/_DSF3071-Edit-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-WSh3Nqv/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "1920's style police call box being used by a townsperson to call in a crime.",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 1
  },
  {
    "id": "i-KMhKvRb",
    "title": "",
    "description": "",
    "alt": "_DSF2686-Edit.jpg",
    "src": "https://photos.smugmug.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-KMhKvRb/0/L6VbfjVFFs7S9gZN4m6kFB69Wjd5CFvPJd9kRdrGd/XL/_DSF2686-Edit-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-KMhKvRb/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 2
  },
  {
    "id": "i-k9qB2jV",
    "title": "",
    "description": "",
    "alt": "_DSF3141-Edit-Edit-2.jpg",
    "src": "https://photos.smugmug.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-k9qB2jV/0/LjFmtmrc8FL85V9B5h3vn8mhsGqJSsNzgGKz6Jwzh/XL/_DSF3141-Edit-Edit-2-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-k9qB2jV/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 3
  },
  {
    "id": "i-VqxgW5k",
    "title": "Just a Typical Saturday Afternoon",
    "description": "Farmers passing time in the rocking chair on the front porch on a Saturday afternoon in the South.",
    "alt": "Just a Typical Saturday Afternoon",
    "src": "https://photos.smugmug.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-VqxgW5k/0/Lgt4gLkn4GNbwWpHKbwJ4TQbB8DQVNZM53DB2Ln2z/XL/_DSF2500-Edit-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-VqxgW5k/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "Farmers passing time in the rocking chair on the front porch on a Saturday afternoon in the South.",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 4
  },
  {
    "id": "i-NVz5zk2",
    "title": "",
    "description": "",
    "alt": "_DSF3125-Edit.jpg",
    "src": "https://photos.smugmug.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-NVz5zk2/0/LKG5RDNQntkNFpB8ZGHjRTB3DrwC4CVC2Qvdh38SN/XL/_DSF3125-Edit-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-NVz5zk2/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 5
  },
  {
    "id": "i-9cZHdvB",
    "title": "",
    "description": "",
    "alt": "_O1H0037-Edit.jpg",
    "src": "https://photos.smugmug.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-9cZHdvB/0/NQrTx4fJfZPL2VvDFxRWmTtJQXvtvPbRCLrLb4vgz/XL/_O1H0037-Edit-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-9cZHdvB/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 6
  },
  {
    "id": "i-zrVCpMP",
    "title": "",
    "description": "",
    "alt": "_DSF2514-Edit-2.jpg",
    "src": "https://photos.smugmug.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-zrVCpMP/0/LKZ8vjNh3FNgPCFLcH45jxCqVW9wkM45SbNRPkQrq/XL/_DSF2514-Edit-2-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-zrVCpMP/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 7
  },
  {
    "id": "i-rxnpqCQ",
    "title": "",
    "description": "",
    "alt": "_DSF2516-Edit-2.jpg",
    "src": "https://photos.smugmug.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-rxnpqCQ/0/MnzFJRk5nsPtQdg449PH9MLw3j88cSVLNxqN3gk8B/XL/_DSF2516-Edit-2-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-rxnpqCQ/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 8
  },
  {
    "id": "i-qgJkNtv",
    "title": "",
    "description": "",
    "alt": "_DSF2591-Enhanced-NR-Edit.jpg",
    "src": "https://photos.smugmug.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-qgJkNtv/0/LWj3DjpvmVhfWkrmhxMzwBj9rH2JRwZ64W8SwCGbR/XL/_DSF2591-Enhanced-NR-Edit-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-qgJkNtv/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 9
  },
  {
    "id": "i-6NPsMpH",
    "title": "",
    "description": "",
    "alt": "_DSF2766-Edit-2.jpg",
    "src": "https://photos.smugmug.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-6NPsMpH/0/NTHjt6mhCGxQzKjRGPLm7vTS2rFgcBkbSqrhzzh38/XL/_DSF2766-Edit-2-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-6NPsMpH/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 10
  },
  {
    "id": "i-5CcF5N4",
    "title": "",
    "description": "",
    "alt": "_O1H0938-Edit.jpg",
    "src": "https://photos.smugmug.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-5CcF5N4/0/NfShRBW72mnDmsbrVRn8fLLPHtCfqGvWHFsWrvdsq/XL/_O1H0938-Edit-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-5CcF5N4/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 11
  },
  {
    "id": "i-mMXRvh4",
    "title": "1920's  at Old Bedford Village",
    "description": "Reenactors at Old Bedford Village 1920's event. Gangsters, flappers, bootleggers abound.",
    "alt": "1920's  at Old Bedford Village",
    "src": "https://photos.smugmug.com/Other/Photo-Shoots/Pennsylvania/Old-Bedford-Historical-Village/Roaring-20s/i-mMXRvh4/8/LLsJDmqRDkZdWXngj34HL6F2CjXFv7NdKfjL7Cgrx/XL/_O1H0073-Edit-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-mMXRvh4/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "Reenactors at Old Bedford Village 1920's event. Gangsters, flappers, bootleggers abound.",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 12
  },
  {
    "id": "i-k2W3gQV",
    "title": "1920's  at Old Bedford Village",
    "description": "Reenactors at Old Bedford Village 1920's event. Gangsters, flappers, bootleggers abound.",
    "alt": "1920's  at Old Bedford Village",
    "src": "https://photos.smugmug.com/Other/Photo-Shoots/Pennsylvania/Old-Bedford-Historical-Village/Roaring-20s/i-k2W3gQV/10/MjzzkhsHbkCgsMfHhGqDwmjjBM3MTpHvMzLKCrVFv/XL/_DSF2597-Enhanced-NR-Edit-2-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-k2W3gQV/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "Reenactors at Old Bedford Village 1920's event. Gangsters, flappers, bootleggers abound.",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 13
  },
  {
    "id": "i-m7STjq2",
    "title": "",
    "description": "",
    "alt": "_DSF2612-Edit.jpg",
    "src": "https://photos.smugmug.com/Other/Photo-Shoots/Pennsylvania/Old-Bedford-Historical-Village/Roaring-20s/i-m7STjq2/9/LgpJmgwk5pC9pLtmvTWfjRrK8QJTJV3fss3zn7vGk/XL/_DSF2612-Edit-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-m7STjq2/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 14
  },
  {
    "id": "i-K6mDKMn",
    "title": "1920's  at Old Bedford Village",
    "description": "Reenactors at Old Bedford Village 1920's event. Gangsters, flappers, bootleggers abound.",
    "alt": "1920's  at Old Bedford Village",
    "src": "https://photos.smugmug.com/Other/Photo-Shoots/Pennsylvania/Old-Bedford-Historical-Village/Roaring-20s/i-K6mDKMn/9/LMbcnnQ7MHJ7qwD28bm8pcgSXhZMqgxfJxN6JxmtT/XL/_O1H0307-Edit-2-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-K6mDKMn/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "Reenactors at Old Bedford Village 1920's event. Gangsters, flappers, bootleggers abound.",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 15
  },
  {
    "id": "i-QBKhZS2",
    "title": "",
    "description": "",
    "alt": "_DSF3076-Edit.jpg",
    "src": "https://photos.smugmug.com/Other/Photo-Shoots/Pennsylvania/Old-Bedford-Historical-Village/Roaring-20s/i-QBKhZS2/3/NcKNM8xvfKz7CtR3xmPzTKbq2mQrXJPmJLFwfPmKH/XL/_DSF3076-Edit-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-QBKhZS2/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 16
  },
  {
    "id": "i-pqpdH2v",
    "title": "1920's  at Old Bedford Village",
    "description": "Reenactors at Old Bedford Village 1920's event. Gangsters, flappers, bootleggers abound.",
    "alt": "1920's  at Old Bedford Village",
    "src": "https://photos.smugmug.com/Other/Photo-Shoots/Pennsylvania/Old-Bedford-Historical-Village/Roaring-20s/i-pqpdH2v/8/Ldt5LWNrpKxg2x6wGFqTkFgnsCb9KvBLmLZjZpZ2C/XL/_DSF3175-Edit-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-pqpdH2v/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "Reenactors at Old Bedford Village 1920's event. Gangsters, flappers, bootleggers abound.",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 17
  },
  {
    "id": "i-5bqK2s3",
    "title": "1920's  at Old Bedford Village",
    "description": "Reenactors at Old Bedford Village 1920's event. Gangsters, flappers, bootleggers abound.",
    "alt": "1920's  at Old Bedford Village",
    "src": "https://photos.smugmug.com/Other/Photo-Shoots/Pennsylvania/Old-Bedford-Historical-Village/Roaring-20s/i-5bqK2s3/9/Mm3C7C5MBqQRfVZBPpJtLSjgXpjH7w99VPcPNvSrd/XL/_DSF3362-Edit-2-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-5bqK2s3/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "Reenactors at Old Bedford Village 1920's event. Gangsters, flappers, bootleggers abound.",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 18
  },
  {
    "id": "i-9mDvxMc",
    "title": "1920's  at Old Bedford Village",
    "description": "Reenactors at Old Bedford Village 1920's event. Gangsters, flappers, bootleggers abound.",
    "alt": "1920's  at Old Bedford Village",
    "src": "https://photos.smugmug.com/Other/Photo-Shoots/Pennsylvania/Old-Bedford-Historical-Village/Roaring-20s/i-9mDvxMc/9/KsBpQ6pSNB2qQ5ZMjRKMZxSqtGB6mHnbpxJ5WLpfd/XL/_O1H0933-Edit-2-XL.jpg",
    "buyLink": "https://www.k4studios.com/Galleries/Painterly-Fine-Art-Photography/Facing-History/Roaring-20s-Portraits/Color/i-9mDvxMc/A",
    "keywords": [
      "shoe shine",
      "1920s Bedford Village",
      "roaring 20's"
    ],
    "story": "Reenactors at Old Bedford Village 1920's event. Gangsters, flappers, bootleggers abound.",
    "notes": "",
    "rating": 0,
    "galleries": [
      "Galleries/Painterly-Fine-Art-Photography/Facing-History/Western-Cowboy-Portraits/Black-White"
    ],
    "visibility": "show",
    "sortOrder": 19
  }
];
