// src/components/FAQAccordion.jsx
import React from "react";

export default function FAQAccordion({ items }) {
  return (
    <section className="faq">
      <h2>Frequently Asked Questions</h2>
      {items.map((item, idx) => (
        <details key={idx} open={idx === 0} className="faq-item">
          <summary dangerouslySetInnerHTML={{ __html: `<b>${item.q}</b>` }} />
          <div
            className="faq-content"
            dangerouslySetInnerHTML={{ __html: item.a }}
          />
        </details>
      ))}

      <style jsx>{`
        .faq {
          font-family: "Glegoo", Georgia, "Times New Roman", Times, serif;
          color:rgb(99, 98, 98);
          font-size: .95rem;
          line-height: 1.5;
          background-color: #fff;
          border: 1px solid #d6c3a6;
          border-radius: 12px;
          box-shadow: 0 18px 36px rgba(80, 80, 80, 0.38);
          padding: 1.75rem;
          margin: 4rem auto;
          max-width: 950px;
          position: relative;
          z-index: 10;
        }

        .faq * {
          font-family: inherit;
        }

        .faq h2 {
          font-size: 1.25rem;
          font-weight: 600;
          text-align: center;
          border-bottom: 2px solid #bbb1a2;
          padding-bottom: 0.5rem;
          margin-bottom: 1.5rem;
        }

        .faq-item {
          overflow: hidden;
          transition: all 0.4s ease-in-out;
        }

        .faq-content {
          max-height: 0;
          opacity: 0;
          transform: translateY(-8px);
          overflow: hidden;
          transition:
            max-height 0.8s ease-in-out,
            opacity 0.6s ease-in-out,
            transform 0.6s ease-in-out;
        }

        .faq-item[open] .faq-content {
          max-height: 1000px;
          opacity: 1;
          transform: translateY(0);
        }

        .faq details {
          margin-bottom: 1.5rem;
          border-bottom: 1px solid #a8a197;
          padding-bottom: 1rem;
        }

        .faq details:hover {
          background-color: #f0ece7;
        }

        .faq summary {
          scroll-margin-top: 100px;
          font-weight: 500;
          font-size: 1.1rem;
          color:rgb(110, 98, 86);
          margin-bottom: 0.25rem;
          list-style: none;
          display: block;
          cursor: pointer;
        }

        .faq summary:hover {
          color:rgb(175, 158, 142);
        }

        .faq p {
          font-size: 1rem;
          color:rgb(95, 81, 70);
          margin-top: 0.5rem;
          padding-left: 1.5rem;
        }

        .faq ul {
          list-style-type: disc;
          padding-left: 90px;
          margin-top: 0.75rem;
          margin-bottom: 1rem;
          color:rgb(85, 72, 62);
          font-size: 1rem;
        }

        .faq li {
          margin-bottom: 0.5rem;
          line-height: 1.5;
        }

        @media screen and (max-width: 768px) {
          .faq {
            padding: 1.25rem;
          }

          .faq h2 {
            font-size: 1.5rem;
          }

          .faq summary {
            font-size: 1.125rem;
          }
        }
      `}</style>
    </section>
  );
}
