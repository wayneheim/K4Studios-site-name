// GalleryToggleButton.jsx
export default function GalleryToggleButton({ galleryType, colorUrl, bwUrl }) {
  if (colorUrl && bwUrl) {
    if (galleryType === "color") {
      return (
        <a
          href={bwUrl}
          className="gallery-toggle-btn"
          aria-label="View Black & White Gallery"
        >
          B/W
        </a>
      );
    }
    if (galleryType === "bw") {
      return (
        <a
          href={colorUrl}
          className="gallery-toggle-btn"
          aria-label="View Color Gallery"
        >
          Color
        </a>
      );
    }
  }
  return null;
}
