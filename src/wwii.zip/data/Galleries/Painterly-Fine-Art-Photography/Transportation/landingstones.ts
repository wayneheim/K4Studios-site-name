export const landingWestern = {
    //Painterly Transporation Photogrqphy
  title: "Paintery Transportation Themed Photography by Wayne Heim",
  subtitle: "Fine Art Painterly Photos of Vehicles & Motion",
   breadcrumb: "Painterly Photography: Transportaion",

  tombstones: [
    {
      title: 'Trains & Locomotives: Color Photos',
      href: '/Galleries/Painterly-Fine-Art-Photography/Transportation/Trains-Color',
      thumb: 'https://photos.smugmug.com/Other/Photo-Shoots/Pennsylvania/East-Broad-Top-RR-Rockhill-PA/i-38H7pXm/0/LN6Xwhtp6hzsxJ8x3R735M42KF79fhxsnzv4VCLk4/S/_O1H1398-Edit-S.jpg',
    },
    {
      title: 'Trains & Locomotives: B/W Photos',
      href: '/Galleries/Painterly-Fine-Art-Photography/Transportation/Trains-Black-White',
      thumb: 'https://photos.smugmug.com/Other/Photo-Shoots/Pennsylvania/Easst-Broad-Top-Railroad-Fall-23/i-NXqvv7J/0/NPsvjrbF8dSwMTDMJbwtW2zcwMXPcVq6VbHnHvGFQ/S/_HF26382-S.jpg',
    },
     {
      title: 'Classic Car Photos',
      href: '/Galleries/Painterly-Fine-Art-Photography/Transportation/Trains-Black-White',
      thumb: 'https://photos.smugmug.com/Other/Photo-Shoots/Pennsylvania/East-Broad-Top-RR-Rockhill-PA/i-wkRb273/1/LjTmmDC5fJgXRfRR3p3XM7Kq4s4HQLNb8FBDPhx3J/S/_DSF0260-S.jpg',
    },
    
  ]
};
