export const landingWestern = {
    //Engrained Series
  title: "The Engrained Series",
  subtitle: "Engrained by Wayne Heim – Custom Wood Prints of Painterly Western Art, WWII & Historic Scenes",
   breadcrumb: "Painterly Photography: Engrained Series",

  tombstones: [
    
    {
      title: 'Engrained Series',
      href: '/Other/Print-Options/Prints-on-Wood',
      thumb: '/images/tombstones/engrained-ts.jpg',
    },
  ]
};
