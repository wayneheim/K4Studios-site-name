export const landingWestern = {
    //Painterly Transporation Photogrqphy
  title: "Paintery Miscellaneous Portrait Photography",
  subtitle: "Fine Art Painterly Portraits & Moments",
   breadcrumb: "Painterly Photography: Misc. Portraits",

  tombstones: [
    {
      title: 'Fine Art Painterly Portrait Photos',
      href: '/Galleries/Painterly-Fine-Art-Photography/Miscellaneous/Portraits',
      thumb: 'https://photos.smugmug.com/Other/Photo-Shoots/Scheduled-Shoots/Deb-and-Cody-Wedding/i-LcWbnLw/0/MhZRdpjnR3dQZCTsWDZfBRQXvMjCwVN5xPMhj5gcr/S/_FWH7909-Enhanced-NR-Edit-S.jpg',
    },
      
  ]
};
