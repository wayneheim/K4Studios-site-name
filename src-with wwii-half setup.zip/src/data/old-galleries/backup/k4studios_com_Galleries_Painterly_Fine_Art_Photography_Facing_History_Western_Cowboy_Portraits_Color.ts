export const galleryData = [];
